
import * as React from 'react';
import BoardList from './Board/BoardList';

export default function About() {

  return (
    <>
    <BoardList/>
    </>
  );
}